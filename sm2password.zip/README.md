# Password

## 简介

`Password`是一个用于保存密码的私有化部署服务。使用 go 语言开发后端，使用 Typejs + vue 开发前端。

`Password`目前支持 web 客户端，支持手机小屏幕和电脑大屏幕。

`Password`具有端到端加密的特性，使用国密`sm2`+`sm4`进行前后端通讯交互，不怕中途被截取密码数据。

`Password`后端存储在数据库的`账号`和`密码`也是经过加密处理进行保存，不容易被运维人员进行查看。

## 项目体验地址

[点击我体验一下](http://116.198.216.22:3333)

账号: test, 密码: 123456

## 项目效果图

### 电脑屏幕

- 登录页面

  ![image-20250313170856393](images/README/image-20250313170856393.png)

- 首页

  ![image-20250313171642573](images/README/image-20250313171642573.png)

- 查看密码

  ![image-20250313171658086](images/README/image-20250313171658086.png)

- 详情页面

  ![image-20250313171711473](images/README/image-20250313171711473.png)

- 创建页面

  ![image-20250313171742397](images/README/image-20250313171742397.png)

- 个人页

  ![image-20250313171820374](images/README/image-20250313171820374.png)

### 手机屏幕

<img src="images/README/image-20250313172040615.png" alt="image-20250313172040615" style="zoom:33%;" /><img src="images/README/image-20250313172319540.png" alt="image-20250313172319540" style="zoom:33%;" /><img src="images/README/image-20250313172340108.png" alt="image-20250313172340108" style="zoom:33%;" />

<img src="images/README/image-20250313172359538.png" alt="image-20250313172359538" style="zoom:33%;" /><img src="images/README/image-20250313172513055.png" alt="image-20250313172513055" style="zoom:33%;" /><img src="images/README/image-20250313172446213.png" alt="image-20250313172446213" style="zoom:33%;" />

## 部署安装

### docker compose 部署

#### 一键启动（源码仓库直接运行）

```shell
git clone https://gitee.com/ouhaoqiang/passwordserver
cd passwordserver

# 首次启动会自动构建镜像并初始化 PostgreSQL / Redis / Casdoor
docker compose up -d --build
```

#### 访问地址

- 前端：`http://127.0.0.1:3333`
- Casdoor：`http://127.0.0.1:3334`

#### 已自动处理（无需手工步骤）

- 自动构建 `passwordserver` / `passwordweb` 镜像（无需手工 `docker build`）
- 自动创建 PostgreSQL 数据库：`passwordserver`、`casdoor`
- 前端 Nginx 自动使用容器 DNS 代理后端服务（无需手工改 `nginx.conf`）
- 前端启动时自动获取后端生成的 SM2 公钥（无需去数据库抄 `t_sm2_info`）
- 后端启动时自动读取 Casdoor 内置应用 `app-built-in` 的 `clientId/clientSecret/certificate`

#### 常用命令

```shell
# 查看日志
docker compose logs -f

# 停止服务（保留数据卷）
docker compose down

# 停止并清空数据（下次启动会重新初始化数据库和 Casdoor）
docker compose down -v
```

#### 自定义配置（可选）

- 默认配置已可直接运行。
- 如需对接外部 `postgres` / `redis` / `casdoor`，再修改 `server/deploy/config/config.yaml.example`、`middleware/casdoor/conf/app.conf`、`docker-compose.yaml`。



## 开发环境

### 前端开发环境

> 前端需要 nodejs 环境进行开发

> 使用 ts + vue3 架构

```shell
git clone https://gitee.com/ouhaoqiang/passwordserver
cd passwordserver/web

# 安装依赖
npm install

# 修改开发配置
## 修改后端地址和端口
vite.config.ts
## 从后端获取sm2公钥并配置上去
public/config.ts


# 运行起来
npm run dev

# 编译
npm run build
```

### 后端开发环境

> 后端使用 go 语言镜像开发

> fiber + gorm

```shell
git clone https://gitee.com/ouhaoqiang/passwordserver
cd passwordserver/server

# 修改配置
## 重点需要修改postgres、redis、casdoor配置
deploy/config/config.yaml

# 编译
make

# 运行
make run
```

## 打包

### 打包镜像

> 镜像分为`passwordserver`和`passwordweb`两个

#### 编译全部镜像

```shell
git clone https://gitee.com/ouhaoqiang/passwordserver
cd passwordserver
make
```

#### 单独编译前度或后端镜像

```shell
git clone https://gitee.com/ouhaoqiang/passwordserver
cd passwordserver

# 编译前端
make build-web-image

# 编译后端
make build-server-image
```

#### 编译并保存镜像

```shell
git clone https://gitee.com/ouhaoqiang/passwordserver
cd passwordserver

# 保存所有镜像
make build-all-image-save

# 保存前端
make build-web-image-save

# 保存后端
make build-server-image-save

# 保存目录
ls ./buildSave/
passwordserver.tar
passwordweb.tar
```

### 打包`docker-compose`包

```shell
git clone https://gitee.com/ouhaoqiang/passwordserver
cd passwordserver

make docker-compose-build

# 保存目录
ls ./buildSave/
passwordserver-docker-compose
passwordserver-docker-compose.tar.gz
```

## 实现功能时间线

- 2026-01-29

  fix: 由于int类型的id太长，会导致前端丢失精度，所以改为使用uuid string类型作为id。旧版本数据库需要手动迁移数据和id类型。

- 2025-03-13

  优化前端对后端返回的错误显示，解决在创建密码记录是如果 sessionid 过期会失败。

- 2025-03-12

  支持打包镜像，实现 docker-compose 运行服务。

- 2025-03-07

  二期功能实现: 后端实现账号和密码存储到数据库的加密功能

- 2025-03-06

  二期功能实现: 实现前后端使用国密算法加密传输数据

- 2025-03-04

  实现前后端弱密码显示功能

- 2025-03-04

  完成前端显示样式优化，基本已经完成一期功能实现

- 2025-02-28

  退出时清理 token

- 2025-02-27

  集成支持[casdoor](https://github.com/casdoor/casdoor)登录

- 2025-02-20

  完成前端功能开发，实现登录页面、密码列表页面、密码详情页面、密码编辑页面、密码添加页面、密码搜索功能、密码排序页面、密码复制页面、密码生成页面、密码分类页面。

- 2025-02-19

  完成后端功能开发，实现登录功能接口、密码的增删改查接口、支持存储数据到`postgresql`。

## 待实现功能

1. 2025-03-04

看是否能实现浏览器插件功能

2. 2025-03-07

实现添加配置控制保存在数据库的账号和密码是否加密存储，当解密失败时直接返回数据库保存的内容

3. 2025-03-17

记录获取密码接口请求信息，在数据库中记录，包括时间、ip、用户id、密码记录id等信息。并在后端提供展示查看记录api接口，在前端新添加页面展示。
